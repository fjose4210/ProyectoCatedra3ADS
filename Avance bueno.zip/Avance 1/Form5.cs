﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Avance_1
{
    public partial class Form5 : Form
    {
        private ConexionBD mConexion;
        public Form5()
        {
            InitializeComponent();
            mConexion = new ConexionBD();

        }
       
        private void btn_salir_Click(object sender, EventArgs e)
        {
            // Cierra Form3 y abre Form2
            this.Hide();  // Oculta el Form3
            Form2 form2 = new Form2();
            form2.ShowDialog();
            this.Close();  // Cierra Form3 después de que Form2 se cierre
        }

        private void btn_Agregar_Click(object sender, EventArgs e)
        {
            string Clinica = txt_Descrip.Text;
            string direccion = txt_Direcc.Text;
            string telefono = Txt_telef.Text;
            string email = Txt_email.Text;
            
            // Verificar si algunos campos necesarios están vacíos
            if (string.IsNullOrEmpty(Clinica) || string.IsNullOrEmpty(direccion) ||
                string.IsNullOrEmpty(telefono) || string.IsNullOrEmpty(email))
            {
                MessageBox.Show("Por favor, complete todos los campos necesarios.");
                return;
            }

            string consultainsert = "INSERT INTO clinica (nombre, direccion, telefono, email) " +
                                    "VALUES (@Clinica, @direccion, @telefono, @email)";

            using (MySqlConnection conexion = mConexion.GetConexion())
            {
                try
                {
                    conexion.Open();
                    if (conexion != null)
                    {
                        using (MySqlCommand comando = new MySqlCommand(consultainsert, conexion))
                        {
                            comando.Parameters.AddWithValue("@Clinica", Clinica);
                            comando.Parameters.AddWithValue("@direccion", direccion);
                            comando.Parameters.AddWithValue("@telefono", telefono);
                            comando.Parameters.AddWithValue("@email", email);
                            
                            comando.ExecuteNonQuery();
                            MessageBox.Show("Registro insertado correctamente");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error al conectar con la base de datos");
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error al insertar el registro: " + ex.Message);
                }
            }
        }
    }
}
