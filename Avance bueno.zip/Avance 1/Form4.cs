﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Avance_1
{
    public partial class Form4 : Form
    {
        private ConexionBD mConexion;
        public Form4()
        {
            InitializeComponent();
            mConexion = new ConexionBD();
            // Inicializa el ComboBox de estado
            Cb_Estado.Items.AddRange(new string[] { "Inicio", "Espera", "En Proceso", "Pendiente", "Cancelado", "Completado", "Entregado" });
            Cb_Estado.SelectedIndex = -1;

            // Inicializa el ComboBox de estado
            cm_estado.Items.AddRange(new string[] { "Inicio", "Espera", "En Proceso", "Pendiente", "Cancelado", "Completado", "Entregado" });
            cm_estado.SelectedIndex = -1;
        }
        
        private void btn_salir_Click(object sender, EventArgs e)
        {
            // Cierra Form3 y abre Form2
            this.Hide();  // Oculta el Form3
            Form2 form2 = new Form2();
            form2.ShowDialog();
            this.Close();  // Cierra Form3 después de que Form2 se cierre
        }

        private void btn_Buscar_Click(object sender, EventArgs e)
        {
            BuscarRegistros();

        }
        private void BuscarRegistros()
        {
            
            string estado = Cb_Estado.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(estado))
            {
                MessageBox.Show("Por favor, seleccione un estado.");
                return;
            }

            string consulta = "SELECT * FROM orden_trabajo WHERE estado = @estado";
            DataTable dataTable = new DataTable();

            using (MySqlConnection conexion = mConexion.GetConexion())
            {
                try
                {
                    dataTable.Clear();
                    conexion.Open();
                    if (conexion.State == ConnectionState.Open)
                    {
                        using (MySqlCommand comando = new MySqlCommand(consulta, conexion))
                        {
                            comando.Parameters.AddWithValue("@estado", estado);

                            using (MySqlDataAdapter adapter = new MySqlDataAdapter(comando))
                            {
                                dataTable.Clear(); // Limpia el DataTable para evitar datos duplicados
                                dataGridView1.DataSource = null; // Desvincula el DataGridView del DataTable
                                adapter.Fill(dataTable);
                                dataGridView1.DataSource = dataTable;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error al conectar con la base de datos");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error al buscar los registros: " + ex.Message + "\n" + ex.StackTrace);
                }
                finally
                {
                    if (conexion != null && conexion.State == ConnectionState.Open)
                    {
                        conexion.Close(); // Cierra la conexión en el bloque finally para asegurarse de que siempre se cierre
                    }
                }
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                // Suponiendo que tienes controles de TextBox para los otros campos
                txt_orden.Text = row.Cells["id_orden"].Value.ToString();
                txt_Descrip.Text = row.Cells["descripcion_trabajo"].Value.ToString();
                txt_idprote.Text = row.Cells["id_protesis"].Value.ToString();
                txt_clinica.Text = row.Cells["clinica"].Value.ToString();
                cm_estado.SelectedItem = row.Cells["estado"].Value.ToString();

                // Deshabilitar todos los campos excepto el de estado
                txt_orden.Enabled = false;
                txt_Descrip.Enabled = false;
                txt_idprote.Enabled = false;
               
                txt_clinica.Enabled = false;
                cm_estado.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    DataGridViewRow row = dataGridView1.SelectedRows[0];
                    string idOrden = row.Cells["id_orden"].Value.ToString(); // Asegúrate de tener una columna 'id_orden' en tu DataGridView
                    string nuevoEstado = cm_estado.SelectedItem?.ToString();

                    if (!string.IsNullOrEmpty(nuevoEstado))
                    {
                        string consulta = "UPDATE orden_trabajo SET estado = @estado WHERE id_orden = @id_orden";

                        using (MySqlConnection conexion = mConexion.GetConexion())
                        {
                            try
                            {
                                conexion.Open();
                                if (conexion.State == ConnectionState.Open)
                                {
                                    using (MySqlCommand comando = new MySqlCommand(consulta, conexion))
                                    {
                                        comando.Parameters.AddWithValue("@estado", nuevoEstado);
                                        comando.Parameters.AddWithValue("@id_orden", idOrden);

                                        int filasAfectadas = comando.ExecuteNonQuery();
                                        if (filasAfectadas > 0)
                                        {
                                            MessageBox.Show("Estado actualizado correctamente.");
                                        }
                                        else
                                        {
                                            MessageBox.Show("Error al actualizar el estado.");
                                        }
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("Error al conectar con la base de datos");
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Error al actualizar el estado: " + ex.Message + "\n" + ex.StackTrace);
                            }
                            finally
                            {
                                if (conexion != null && conexion.State == ConnectionState.Open)
                                {
                                    conexion.Close();
                                }
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Por favor, seleccione un estado.");
                    }
                }
                else
                {
                    MessageBox.Show("Por favor, seleccione una fila.");
                }
            }
        }
    }

}
