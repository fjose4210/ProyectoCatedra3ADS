﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using FluentValidation;
namespace Avance_1
{
    public partial class Form3 : Form
    {
        private ConexionBD mConexion;
        public Form3()
        {
            InitializeComponent();
            mConexion = new ConexionBD();
            // Inicializa el ComboBox de estado
            Cb_Estado.Items.Add("Inicio");
            Cb_Estado.Items.Add("Espera");
            Cb_Estado.SelectedIndex = -1;
            // Inicializa el ComboBox de id_protesis
            cm_idpro.Items.Add("1");
            cm_idpro.Items.Add("2");
            cm_idpro.Items.Add("3");
            cm_idpro.Items.Add("4");
            cm_idpro.Items.Add("5");
            cm_idpro.Items.Add("6");
            cm_idpro.Items.Add("7");
            cm_idpro.Items.Add("8");
            cm_idpro.Items.Add("9");
            cm_idpro.Items.Add("10");
            cm_idpro.Items.Add("11");
            cm_idpro.SelectedIndex = -1;
            // Inicializa el ComboBox de tipo de protesis
            cb_tippro.Items.Add("1");
            cb_tippro.Items.Add("2");
            cb_tippro.Items.Add("3");
            cb_tippro.Items.Add("4");
            cb_tippro.Items.Add("5");
            cb_tippro.SelectedIndex = -1;
        }
       
        private void Form3_Load(object sender, EventArgs e)
        {
            
            this.Load += new System.EventHandler(this.Form3_Load);

        }

        private void CargarDatos()
        {
           
        }
        private void btn_Agregar_Click(object sender, EventArgs e)
        {
            string idprotesis = cm_idpro.SelectedItem?.ToString();
            string descripcion = txt_Descrip.Text;
            string tip_prot = cb_tippro.SelectedItem?.ToString();
            string client = txt_Cliente.Text;
            string estado = Cb_Estado.SelectedItem?.ToString();
            DateTime fechaSolicitud = Dt_fecSol.Value; // Asegúrate de tener un DateTimePicker llamado dtpFechaSolicitud
            DateTime fechaEntrega = Dt_fec_entre.Value; // Asegúrate de tener un DateTimePicker llamado dtpFechaEntrega

            // Verificar si algunos campos necesarios están vacíos
            if (string.IsNullOrEmpty(idprotesis) || string.IsNullOrEmpty(descripcion) ||
                string.IsNullOrEmpty(tip_prot) || string.IsNullOrEmpty(client) || string.IsNullOrEmpty(estado))
            {
                MessageBox.Show("Por favor, complete todos los campos necesarios.");
                return;
            }

            string consultainsert = "INSERT INTO orden_trabajo (descripcion_trabajo, id_protesis, fec_sol, fec_entre, clinica, estado) " +
                                    "VALUES (@Descripcion, @id_prote, @fecha_sol, @fecha_entre, @clinica, @estado)";

            using (MySqlConnection conexion = mConexion.GetConexion())
            {
                try
                {
                    conexion.Open();
                    if (conexion != null)
                    {
                        using (MySqlCommand comando = new MySqlCommand(consultainsert, conexion))
                        {
                            comando.Parameters.AddWithValue("@Descripcion", descripcion);
                            comando.Parameters.AddWithValue("@id_prote", idprotesis);
                            comando.Parameters.AddWithValue("@fecha_sol", fechaSolicitud);
                            comando.Parameters.AddWithValue("@fecha_entre", fechaEntrega);
                            comando.Parameters.AddWithValue("@clinica", client);
                            comando.Parameters.AddWithValue("@estado", estado);

                            comando.ExecuteNonQuery();
                            MessageBox.Show("Registro insertado correctamente");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error al conectar con la base de datos");
                    }
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Error al insertar el registro: " + ex.Message);
                }
            }
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            // Cierra Form3 y abre Form2
            this.Hide();  // Oculta el Form3
            Form2 form2 = new Form2();
            form2.ShowDialog();
            this.Close();  // Cierra Form3 después de que Form2 se cierre
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

