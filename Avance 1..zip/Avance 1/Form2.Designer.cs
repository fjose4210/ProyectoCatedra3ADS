﻿
namespace Avance_1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.btn_ord_trab = new System.Windows.Forms.Button();
            this.btn_seguimiento = new System.Windows.Forms.Button();
            this.btn_info_cliente = new System.Windows.Forms.Button();
            this.btn_Usuarios = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_salir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_ord_trab
            // 
            this.btn_ord_trab.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ord_trab.Location = new System.Drawing.Point(149, 92);
            this.btn_ord_trab.Name = "btn_ord_trab";
            this.btn_ord_trab.Size = new System.Drawing.Size(273, 87);
            this.btn_ord_trab.TabIndex = 0;
            this.btn_ord_trab.Text = "Ordenes de Trabajo";
            this.btn_ord_trab.UseVisualStyleBackColor = true;
            this.btn_ord_trab.Click += new System.EventHandler(this.btn_ord_trab_Click);
            // 
            // btn_seguimiento
            // 
            this.btn_seguimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_seguimiento.Location = new System.Drawing.Point(149, 211);
            this.btn_seguimiento.Name = "btn_seguimiento";
            this.btn_seguimiento.Size = new System.Drawing.Size(273, 87);
            this.btn_seguimiento.TabIndex = 1;
            this.btn_seguimiento.Text = "Seguimiento ";
            this.btn_seguimiento.UseVisualStyleBackColor = true;
            this.btn_seguimiento.Click += new System.EventHandler(this.btn_seguimiento_Click);
            // 
            // btn_info_cliente
            // 
            this.btn_info_cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_info_cliente.Location = new System.Drawing.Point(149, 332);
            this.btn_info_cliente.Name = "btn_info_cliente";
            this.btn_info_cliente.Size = new System.Drawing.Size(273, 87);
            this.btn_info_cliente.TabIndex = 2;
            this.btn_info_cliente.Text = "Información del Cliente";
            this.btn_info_cliente.UseVisualStyleBackColor = true;
            this.btn_info_cliente.Click += new System.EventHandler(this.btn_info_cliente_Click);
            // 
            // btn_Usuarios
            // 
            this.btn_Usuarios.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Usuarios.Location = new System.Drawing.Point(149, 444);
            this.btn_Usuarios.Name = "btn_Usuarios";
            this.btn_Usuarios.Size = new System.Drawing.Size(273, 87);
            this.btn_Usuarios.TabIndex = 3;
            this.btn_Usuarios.Text = "Gestión Usuarios";
            this.btn_Usuarios.UseVisualStyleBackColor = true;
            this.btn_Usuarios.Click += new System.EventHandler(this.btn_Usuarios_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(141, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(298, 46);
            this.label1.TabIndex = 4;
            this.label1.Text = "Menú Principal";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_salir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_salir.BackgroundImage")));
            this.btn_salir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btn_salir.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_salir.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.btn_salir.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btn_salir.ImageKey = "(ninguno)";
            this.btn_salir.Location = new System.Drawing.Point(461, 444);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(115, 92);
            this.btn_salir.TabIndex = 9;
            this.btn_salir.UseVisualStyleBackColor = false;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 569);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Usuarios);
            this.Controls.Add(this.btn_info_cliente);
            this.Controls.Add(this.btn_seguimiento);
            this.Controls.Add(this.btn_ord_trab);
            this.Name = "Form2";
            this.Text = "Sistema de Laboratorio Dental \"Bendición de Dios\"";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_ord_trab;
        private System.Windows.Forms.Button btn_seguimiento;
        private System.Windows.Forms.Button btn_info_cliente;
        private System.Windows.Forms.Button btn_Usuarios;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_salir;
    }
}