﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Avance_1
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
           
        }
    
        private void btn_salir_Click(object sender, EventArgs e)
        {
            // Cierra Form3 y abre Form2
            this.Hide();  // Oculta el Form3
            Form2 form2 = new Form2();
            form2.ShowDialog();
            this.Close();  // Cierra Form3 después de que Form2 se cierre
        }
    }
}
