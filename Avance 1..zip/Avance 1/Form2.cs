﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Avance_1
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
           
        }
       
        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

       private void btn_ord_trab_Click(object sender, EventArgs e)
        {
            Form3 Ord_trabForm3 = new Form3();
           
            Ord_trabForm3.Show();
            this.Hide();
        }

        private void btn_seguimiento_Click(object sender, EventArgs e)
        {
            Form4 Segui_Form4 = new Form4();
            
            Segui_Form4.Show();
            this.Hide();
        }

        private void btn_info_cliente_Click(object sender, EventArgs e)
        {
            Form5 Info_Clie_Form5 = new Form5();
            
            Info_Clie_Form5.Show();
            this.Hide();
        }

        private void btn_Usuarios_Click(object sender, EventArgs e)
        {
            Form6 Gest_Usu_Form6 = new Form6();
            
            Gest_Usu_Form6.Show();
            this.Hide();
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
